-- KAYA Nexus Operator 2.0.0
-- Run in Supabase SQL Editor. These indexes prevent the delivery worker
-- from scanning the entire runtime_events table on every poll.

create index if not exists runtime_events_delivery_queue_idx
on public.runtime_events (delivery_channel, sent, status, created_at);

create index if not exists runtime_events_delivery_stale_idx
on public.runtime_events (delivery_channel, sent, status, updated_at);

-- Recommended if runtime_events receives very high volume:
-- keep old terminal events archived by the runtime rather than making
-- the live delivery queue grow without bound.
